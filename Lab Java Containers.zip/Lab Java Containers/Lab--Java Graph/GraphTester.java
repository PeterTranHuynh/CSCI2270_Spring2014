

public class GraphTester
{
	public static void main(String[] args)
	{
		Graph g = new Graph(5);
		g.addEdge(0, 2, 1);
		g.addEdge(2, 4, 1);
		g.addEdge(4, 1, 1);
		g.addEdge(1, 3, 1);
		g.addEdge(3, 0, 1);
		
					
	}
}
